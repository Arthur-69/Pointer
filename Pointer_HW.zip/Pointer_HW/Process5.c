#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        // Child process
        printf("Child process: PID = %d\n", getpid());
    } else {
        // Parent does not call wait()
        printf("Parent process: PID = %d\n", getpid());
        sleep(10);  // Delay to observe the zombie process
    }

    return 0;
}