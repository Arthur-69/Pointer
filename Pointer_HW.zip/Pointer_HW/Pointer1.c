#include <stdio.h>

int main() {
    int x = 10;
    int *ptr = &x;

    // Print the address of x using the variable and pointer
    printf("Address of x: %p\n", (void*)&x);
    printf("Address using pointer: %p\n", (void*)ptr);

    // Modify the value of x using the pointer
    *ptr = 20;
    printf("New value of x: %d\n", x);

    return 0;
}