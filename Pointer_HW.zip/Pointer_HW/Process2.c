#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid1, pid2;
    int status;

    pid1 = fork();

    if (pid1 == 0) {
        // First child
        printf("First child: PID = %d\n", getpid());
        _exit(1);  // Child exits
    } else {
        // Parent waits for the first child
        wait(&status);
        printf("First child exit status: %d\n", WEXITSTATUS(status));

        // Create second child
        pid2 = fork();
        if (pid2 == 0) {
            printf("Second child: PID = %d\n", getpid());
            _exit(2);  // Second child exits
        } else {
            // Parent waits for the second child
            waitpid(pid2, &status, 0);
            printf("Second child exit status: %d\n", WEXITSTATUS(status));
        }
    }

    return 0;
}