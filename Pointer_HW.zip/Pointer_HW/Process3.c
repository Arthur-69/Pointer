#include <stdio.h>
#include <stdlib.h>

void func1() {
    printf("Function 1 executed.\n");
}

void func2() {
    printf("Function 2 executed.\n");
}

int main() {
    // Register functions with atexit
    atexit(func1);
    atexit(func2);

    printf("Program is terminating.\n");
    exit(0);
}