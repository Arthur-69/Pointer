#include <stdio.h>

int main() {
    int x = 30;
    int *p = &x;
    int **pp = &p;

    // Print the value of x using both pointer and double-pointer
    printf("Value of x using pointer: %d\n", *p);
    printf("Value of x using double-pointer: %d\n", **pp);

    return 0;
}