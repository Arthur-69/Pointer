#include <stdio.h>

int main() {
    int arr[5] = {1, 2, 3, 4, 5};
    int *p = arr;

    // Traverse and print array elements using pointer
    for (int i = 0; i < 5; i++) {
        printf("Element %d: %d\n", i, *(p + i));
    }

    // Modify array values using pointer arithmetic
    for (int i = 0; i < 5; i++) {
        *(p + i) *= 2;  // Multiply each element by 2
    }

    // Print the modified array
    printf("Modified array:\n");
    for (int i = 0; i < 5; i++) {
        printf("Element %d: %d\n", i, arr[i]);
    }

    return 0;
}